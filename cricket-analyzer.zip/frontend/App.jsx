import React, { useState } from "react";

export default function App() {
  const [image, setImage] = useState(null);
  const [result, setResult] = useState("");

  const handleUpload = (e) => {
    setImage(e.target.files[0]);
  };

  const analyze = async () => {
    const formData = new FormData();
    formData.append("image", image);

    const res = await fetch("http://localhost:5000/analyze", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();
    setResult(data.result);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>🏏 Cricket AI Analyzer</h1>
      <input type="file" onChange={handleUpload} />
      <br /><br />
      <button onClick={analyze}>Analyze</button>
      <p>{result}</p>
    </div>
  );
}