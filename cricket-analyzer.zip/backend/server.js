import express from "express";
import multer from "multer";
import cors from "cors";
import fs from "fs";
import OpenAI from "openai";

const app = express();
app.use(cors());

const upload = multer({ dest: "uploads/" });

const openai = new OpenAI({
  apiKey: "YOUR_OPENAI_API_KEY",
});

app.post("/analyze", upload.single("image"), async (req, res) => {
  const imageBuffer = fs.readFileSync(req.file.path);

  const response = await openai.responses.create({
    model: "gpt-4.1-mini",
    input: [
      {
        role: "user",
        content: [
          {
            type: "input_text",
            text: `You are a cricket coach. Analyze technique, mistakes, and give improvement tips.`,
          },
          {
            type: "input_image",
            image: imageBuffer.toString("base64"),
          },
        ],
      },
    ],
  });

  fs.unlinkSync(req.file.path);
  res.json({ result: response.output_text });
});

app.listen(5000, () => console.log("Server running"));